import numpy as np
from scipy.io import wavfile
import random
import os

# Tham số cố định
NUM_BITS_TO_EXTRACT = 100   # <-- Đặt thủ công số bit cần tách ở đây
FRAME_SIZE = 1024
HOP_SIZE = 512
FREQ_RANGE = np.linspace(1000, 2000, 100)

# Kiểm tra file âm thanh
if not os.path.exists("stego_audio.wav"):
    print("Lỗi: File stego_audio.wav không tồn tại.")
    exit(1)

# Đọc dữ liệu âm thanh
sample_rate, audio = wavfile.read("stego_audio.wav")
audio = audio.astype(np.float32)

# Thiết lập chuỗi tần số nhảy
random.seed(42)
freq_sequence = random.sample(list(FREQ_RANGE), len(FREQ_RANGE))

# Hàm tách bit từ một frame
def extract_bit(frame, freq, sample_rate, frame_idx):
    fft_data = np.fft.fft(frame)
    freq_bins = np.fft.fftfreq(len(frame), 1/sample_rate)
    freq_idx = np.argmin(np.abs(freq_bins - freq))
    amplitude = np.abs(fft_data[freq_idx])

    # Tính ngưỡng
    nearby_amplitudes = np.abs(fft_data[max(0, freq_idx-5):freq_idx+5])
    threshold = np.mean(nearby_amplitudes) *1.0

    # Debug một số frame đầu
    #if frame_idx < 10:
     #   print(f"[DEBUG] Frame {frame_idx}, Freq {freq:.2f}Hz, Amplitude {amplitude:.2f}, Threshold {threshold:.2f}")

    return "1" if amplitude > threshold else "0"

# Tách chuỗi nhị phân
binary_message = ""
frame_idx = 0

for i in range(0, len(audio) - FRAME_SIZE, HOP_SIZE):
    if len(binary_message) >= NUM_BITS_TO_EXTRACT:
        break
    frame = audio[i:i + FRAME_SIZE]
    freq = freq_sequence[frame_idx % len(freq_sequence)]
    bit = extract_bit(frame, freq, sample_rate, frame_idx)
    binary_message += bit
    frame_idx += 1

# Thống kê và debug
num_ones = binary_message.count("1")
num_zeros = binary_message.count("0")
#print(f"Đã tách {len(binary_message)} bit.")
#print(f"Số bit 1: {num_ones}, Số bit 0: {num_zeros}")
#print(f"Chuỗi nhị phân (50 bit đầu): {binary_message[:50]}")

# Chuyển chuỗi nhị phân sang văn bản
extracted_message = ""
for i in range(0, len(binary_message), 8):
    byte = binary_message[i:i + 8]
    if len(byte) == 8:
        try:
            extracted_message += chr(int(byte, 2))
        except ValueError:
            print(f"[!] Lỗi khi chuyển byte {byte}")
            break

# Ghi ra file
with open("extracted_message.txt", "w", encoding="utf-8") as f:
    f.write(extracted_message)

print("Thông điệp tách ra:", extracted_message)
print("Đã tạo file extracted_message.txt")
